<?php
namespace Database\Seeders;
use App\Models\Role;
use App\Models\Permission;
use Illuminate\Database\Seeder;
class RolePermissionSeeder extends Seeder {
 public function run(): void {
  $map = [
   'platform_admin' => ['platform.tenants.view','platform.tenants.manage','platform.users.view','platform.users.manage','tenant.settings.view','tenant.settings.manage','organization_units.view','organization_units.manage','users.view','users.manage','roles.view','roles.manage','permissions.view','permissions.assign','role_assignments.view','role_assignments.manage','academic.programs.view','academic.programs.manage','academic.courses.view','academic.courses.manage','academic.enrolments.view','academic.enrolments.manage','admissions.applications.view','admissions.applications.manage','examinations.manage','examinations.results.view','examinations.results.publish','students.records.view','students.records.manage','finance.fees.view','finance.fees.manage','hr.employees.view','hr.employees.manage','reports.view','audit_logs.view','example_resources.view','example_resources.create'],
   'institution_admin' => ['tenant.settings.view','tenant.settings.manage','organization_units.view','organization_units.manage','users.view','users.manage','roles.view','roles.manage','permissions.view','role_assignments.view','role_assignments.manage','academic.programs.view','academic.programs.manage','academic.courses.view','academic.courses.manage','academic.enrolments.view','academic.enrolments.manage','admissions.applications.view','admissions.applications.manage','examinations.manage','examinations.results.view','examinations.results.publish','students.records.view','students.records.manage','finance.fees.view','finance.fees.manage','hr.employees.view','hr.employees.manage','reports.view','audit_logs.view','example_resources.view','example_resources.create'],
   'registrar' => ['organization_units.view','users.view','academic.programs.view','academic.programs.manage','academic.courses.view','academic.courses.manage','academic.enrolments.view','academic.enrolments.manage','admissions.applications.view','students.records.view','students.records.manage','examinations.results.view','reports.view'],
   'admissions_officer' => ['academic.programs.view','admissions.applications.view','admissions.applications.manage','students.records.view'],
   'faculty' => ['academic.programs.view','academic.courses.view','academic.enrolments.view','examinations.results.view','students.records.view'],
   'controller_examinations' => ['academic.programs.view','academic.courses.view','academic.enrolments.view','examinations.manage','examinations.results.view','examinations.results.publish','students.records.view','reports.view'],
   'finance_officer' => ['finance.fees.view','finance.fees.manage','reports.view'],
   'hr_officer' => ['hr.employees.view','hr.employees.manage','reports.view'],
   'student' => ['academic.programs.view','academic.courses.view','academic.enrolments.view','examinations.results.view','students.records.view','finance.fees.view'],
   'applicant' => ['academic.programs.view','admissions.applications.view'],
   'parent_guardian' => ['students.records.view','finance.fees.view','examinations.results.view'],
   'auditor' => ['tenant.settings.view','organization_units.view','users.view','roles.view','permissions.view','role_assignments.view','academic.programs.view','academic.courses.view','academic.enrolments.view','admissions.applications.view','examinations.results.view','students.records.view','finance.fees.view','hr.employees.view','reports.view','audit_logs.view'],
  ];
  foreach ($map as $roleCode => $codes) {
   $role = Role::where('code',$roleCode)->firstOrFail();
   $ids = Permission::whereIn('code',$codes)->where('is_active',true)->pluck('id')->all();
   $role->permissions()->sync($ids);
  }
 }
}
