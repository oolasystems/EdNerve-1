<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            ['code' => 'platform_admin', 'name' => 'Platform Administrator', 'scope_type' => 'platform', 'description' => 'OolaEdNerve platform-level administration.'],
            ['code' => 'institution_admin', 'name' => 'Institution Administrator', 'scope_type' => 'tenant', 'description' => 'Institution-wide administration and configuration.'],
            ['code' => 'registrar', 'name' => 'Registrar / Academic Office', 'scope_type' => 'tenant', 'description' => 'Academic administration and student records.'],
            ['code' => 'admissions_officer', 'name' => 'Admissions Officer', 'scope_type' => 'organization', 'description' => 'Admissions processing within assigned institutional scope.'],
            ['code' => 'faculty', 'name' => 'Faculty', 'scope_type' => 'organization', 'description' => 'Teaching and academic activities within assigned scope.'],
            ['code' => 'controller_examinations', 'name' => 'Controller of Examinations', 'scope_type' => 'tenant', 'description' => 'Institution-wide examination administration.'],
            ['code' => 'finance_officer', 'name' => 'Finance Officer', 'scope_type' => 'tenant', 'description' => 'Finance operations within the institution.'],
            ['code' => 'hr_officer', 'name' => 'HR Officer', 'scope_type' => 'tenant', 'description' => 'Human resources operations within the institution.'],
            ['code' => 'student', 'name' => 'Student', 'scope_type' => 'self', 'description' => 'Access to the student’s own permitted records and services.'],
            ['code' => 'applicant', 'name' => 'Applicant', 'scope_type' => 'self', 'description' => 'Access to the applicant’s own application and admission journey.'],
            ['code' => 'parent_guardian', 'name' => 'Parent / Guardian', 'scope_type' => 'self', 'description' => 'Access to explicitly authorized student information.'],
            ['code' => 'auditor', 'name' => 'Auditor / Regulator', 'scope_type' => 'tenant', 'description' => 'Read-only access within an explicitly authorized institutional scope.'],
        ];

        foreach ($roles as $role) {
            Role::updateOrCreate(
                ['code' => $role['code']],
                array_merge($role, [
                    'tenant_id' => null,
                    'is_system' => true,
                    'is_active' => true,
                ])
            );
        }
    }
}
