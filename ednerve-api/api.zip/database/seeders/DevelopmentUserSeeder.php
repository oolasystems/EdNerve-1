<?php
namespace Database\Seeders;
use App\Models\User;
use App\Models\Tenant;
use App\Models\Role;
use App\Models\OrganizationUnit;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
class DevelopmentUserSeeder extends Seeder {
 public function run(): void {
  $password=Hash::make('ChangeMe@2026');
  $admin=User::updateOrCreate(['email'=>'platform.admin@oolaednerve.test'],['name'=>'OolaEdNerve Platform Administrator','phone'=>'9000000000','password'=>$password,'status'=>'active','email_verified_at'=>now()]);
  $platformRole=Role::where('code','platform_admin')->firstOrFail();
  $admin->roleAssignments()->updateOrCreate(['role_id'=>$platformRole->id,'tenant_id'=>null,'organization_unit_id'=>null],['assigned_by'=>null,'starts_at'=>now(),'ends_at'=>null,'is_active'=>true]);

  $roleCodes=['institution_admin','registrar','admissions_officer','faculty','controller_examinations','finance_officer','hr_officer','student','applicant','parent_guardian','auditor'];
  $tenants=Tenant::where('is_active',true)->orderBy('id')->get()->values();
  foreach ($roleCodes as $roleCode) {
   $role=Role::where('code',$roleCode)->firstOrFail();
   for ($i=1;$i<=5;$i++) {
    $tenant=$tenants[($i-1)%$tenants->count()];
    $email=$roleCode.'.'.strtolower($tenant->code).'.'.str_pad((string)$i,2,'0',STR_PAD_LEFT).'@oolaednerve.test';
    $user=User::updateOrCreate(['email'=>$email],['name'=>ucwords(str_replace('_',' ',$roleCode)).' '.$tenant->code.' '.$i,'phone'=>'91'.str_pad((string)(100000000+$i+($tenant->id*1000)),10,'0',STR_PAD_LEFT),'password'=>$password,'status'=>'active','email_verified_at'=>now()]);
    $user->tenants()->syncWithoutDetaching([$tenant->id=>['membership_status'=>'active','joined_at'=>now()]]);
    $orgId=null;
    if ($role->scope_type==='organization') {
     $org=OrganizationUnit::where('tenant_id',$tenant->id)->whereIn('unit_type',['department','centre'])->orderBy('id')->first();
     $orgId=$org?->id;
    }
    $user->roleAssignments()->updateOrCreate(['role_id'=>$role->id,'tenant_id'=>$tenant->id,'organization_unit_id'=>$orgId],['assigned_by'=>$admin->id,'starts_at'=>now(),'ends_at'=>null,'is_active'=>true]);
   }
  }
 }
}
