<?php

namespace Database\Seeders;

use App\Models\Tenant;
use Illuminate\Database\Seeder;

class TenantSeeder extends Seeder
{
    public function run(): void
    {
        $tenants = [
            [
                'code' => 'AMU',
                'name' => 'Aligarh Muslim University',
                'slug' => 'aligarh-muslim-university',
                'institution_type' => 'university',
                'city' => 'Aligarh',
                'state' => 'Uttar Pradesh',
            ],
            [
                'code' => 'JMI',
                'name' => 'Jamia Millia Islamia',
                'slug' => 'jamia-millia-islamia',
                'institution_type' => 'university',
                'city' => 'New Delhi',
                'state' => 'Delhi',
            ],
            [
                'code' => 'JNU',
                'name' => 'Jawaharlal Nehru University',
                'slug' => 'jawaharlal-nehru-university',
                'institution_type' => 'university',
                'city' => 'New Delhi',
                'state' => 'Delhi',
            ],
            [
                'code' => 'BHU',
                'name' => 'Banaras Hindu University',
                'slug' => 'banaras-hindu-university',
                'institution_type' => 'university',
                'city' => 'Varanasi',
                'state' => 'Uttar Pradesh',
            ],
            [
                'code' => 'SPPU',
                'name' => 'Savitribai Phule Pune University',
                'slug' => 'savitribai-phule-university',
                'institution_type' => 'university',
                'city' => 'Pune',
                'state' => 'Maharashtra',
            ],
        ];

        foreach ($tenants as $tenant) {
            Tenant::updateOrCreate(
                ['code' => $tenant['code']],
                array_merge($tenant, [
                    'country' => 'India',
                    'timezone' => 'Asia/Kolkata',
                    'is_active' => true,
                ])
            );
        }
    }
}
