<?php
namespace Database\Seeders;
use App\Models\Tenant;
use App\Models\OrganizationUnit;
use Illuminate\Database\Seeder;
class OrganizationUnitSeeder extends Seeder {
 public function run(): void {
  $structures = [
   'AMU' => [['code'=>'FAC-SCI','name'=>'Faculty of Science','type'=>'faculty','children'=>[['code'=>'DEPT-CS','name'=>'Department of Computer Science','type'=>'department'],['code'=>'DEPT-MATH','name'=>'Department of Mathematics','type'=>'department']]],['code'=>'FAC-ENG','name'=>'Faculty of Engineering & Technology','type'=>'faculty','children'=>[['code'=>'DEPT-CSE','name'=>'Department of Computer Engineering','type'=>'department']]]],
   'JMI' => [['code'=>'FAC-ENG','name'=>'Faculty of Engineering & Technology','type'=>'faculty','children'=>[['code'=>'DEPT-CSE','name'=>'Department of Computer Science','type'=>'department']]],['code'=>'FAC-HUM','name'=>'Faculty of Humanities & Languages','type'=>'faculty','children'=>[['code'=>'DEPT-ENG','name'=>'Department of English','type'=>'department']]]],
   'JNU' => [['code'=>'SCHOOL-COMP','name'=>'School of Computer and Systems Sciences','type'=>'school','children'=>[['code'=>'CENTRE-CS','name'=>'Centre for Computer Systems','type'=>'centre']]],['code'=>'SCHOOL-LANG','name'=>'School of Language, Literature and Culture Studies','type'=>'school','children'=>[['code'=>'CENTRE-LANG','name'=>'Language Centre','type'=>'centre']]]],
   'BHU' => [['code'=>'FAC-SCI','name'=>'Faculty of Science','type'=>'faculty','children'=>[['code'=>'DEPT-CS','name'=>'Department of Computer Science','type'=>'department']]],['code'=>'FAC-ARTS','name'=>'Faculty of Arts','type'=>'faculty','children'=>[['code'=>'DEPT-ENG','name'=>'Department of English','type'=>'department']]]],
   'SPPU' => [['code'=>'FAC-SCI','name'=>'Faculty of Science and Technology','type'=>'faculty','children'=>[['code'=>'DEPT-CS','name'=>'Department of Computer Science','type'=>'department']]],['code'=>'FAC-COM','name'=>'Faculty of Commerce and Management','type'=>'faculty','children'=>[['code'=>'DEPT-MGMT','name'=>'Department of Management Sciences','type'=>'department']]]],
  ];
  foreach ($structures as $tenantCode => $units) {
   $tenant=Tenant::where('code',$tenantCode)->firstOrFail();
   $root=OrganizationUnit::updateOrCreate(['tenant_id'=>$tenant->id,'code'=>'CENTRAL'],['parent_id'=>null,'name'=>'Central Administration','slug'=>'central-administration','unit_type'=>'administration','description'=>'Institution-wide central administration','is_active'=>true]);
   foreach ($units as $unit) {
    $parent=OrganizationUnit::updateOrCreate(['tenant_id'=>$tenant->id,'code'=>$unit['code']],['parent_id'=>$root->id,'name'=>$unit['name'],'slug'=>strtolower(str_replace('_','-',preg_replace('/[^a-z0-9]+/i','-', $unit['code']))),'unit_type'=>$unit['type'],'is_active'=>true]);
    foreach ($unit['children'] as $child) OrganizationUnit::updateOrCreate(['tenant_id'=>$tenant->id,'code'=>$child['code']],['parent_id'=>$parent->id,'name'=>$child['name'],'slug'=>strtolower($child['code']), 'unit_type'=>$child['type'],'is_active'=>true]);
   }
  }
 }
}
