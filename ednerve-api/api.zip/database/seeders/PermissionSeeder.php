<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            ['platform.tenants.view', 'platform', 'View institutions'],
            ['platform.tenants.manage', 'platform', 'Manage institutions'],
            ['platform.users.view', 'platform', 'View platform users'],
            ['platform.users.manage', 'platform', 'Manage platform users'],
            ['tenant.settings.view', 'administration', 'View institution settings'],
            ['tenant.settings.manage', 'administration', 'Manage institution settings'],
            ['organization_units.view', 'administration', 'View organization units'],
            ['organization_units.manage', 'administration', 'Manage organization units'],
            ['users.view', 'identity', 'View users'],
            ['users.manage', 'identity', 'Manage users'],
            ['roles.view', 'identity', 'View roles'],
            ['roles.manage', 'identity', 'Manage roles'],
            ['permissions.view', 'identity', 'View permissions'],
            ['permissions.assign', 'identity', 'Assign permissions'],
            ['role_assignments.view', 'identity', 'View role assignments'],
            ['role_assignments.manage', 'identity', 'Manage role assignments'],
            ['academic.programs.view', 'academics', 'View academic programs'],
            ['academic.programs.manage', 'academics', 'Manage academic programs'],
            ['academic.courses.view', 'academics', 'View courses'],
            ['academic.courses.manage', 'academics', 'Manage courses'],
            ['academic.enrolments.view', 'academics', 'View enrolments'],
            ['academic.enrolments.manage', 'academics', 'Manage enrolments'],
            ['admissions.applications.view', 'admissions', 'View applications'],
            ['admissions.applications.manage', 'admissions', 'Manage applications'],
            ['examinations.manage', 'examinations', 'Manage examinations'],
            ['examinations.results.view', 'examinations', 'View examination results'],
            ['examinations.results.publish', 'examinations', 'Publish examination results'],
            ['students.records.view', 'students', 'View student records'],
            ['students.records.manage', 'students', 'Manage student records'],
            ['finance.fees.view', 'finance', 'View fee records'],
            ['finance.fees.manage', 'finance', 'Manage fee records'],
            ['hr.employees.view', 'hr', 'View employee records'],
            ['hr.employees.manage', 'hr', 'Manage employee records'],
            ['reports.view', 'reports', 'View reports'],
            ['audit_logs.view', 'audit', 'View audit logs'],
            // Phase 2.5 demonstration permissions.
            ['example_resources.view', 'system_demo', 'View example tenant resources'],
            ['example_resources.create', 'system_demo', 'Create example tenant resources'],
        ];
        foreach ($permissions as [$code, $module, $name]) {
            Permission::updateOrCreate(['code' => $code], [
                'module' => $module, 'name' => $name, 'description' => null,
                'is_system' => true, 'is_active' => true,
            ]);
        }
    }
}
