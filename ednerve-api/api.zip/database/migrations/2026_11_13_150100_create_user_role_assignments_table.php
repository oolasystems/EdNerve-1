<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_role_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('role_id')->constrained('roles')->cascadeOnDelete();
            // NULL tenant_id is reserved for platform-level assignments.
            $table->foreignId('tenant_id')->nullable()->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('organization_unit_id')->nullable()->constrained('organization_units')->nullOnDelete();
            $table->foreignId('assigned_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['user_id', 'is_active'], 'ura_user_active_idx');
            $table->index(['role_id', 'tenant_id', 'is_active'], 'ura_role_tenant_active_idx');
            $table->index(['tenant_id', 'organization_unit_id', 'is_active'], 'ura_tenant_org_active_idx');
            $table->index(['starts_at', 'ends_at'], 'ura_dates_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_role_assignments');
    }
};
