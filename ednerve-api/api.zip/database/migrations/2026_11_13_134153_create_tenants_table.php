
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenants', function (Blueprint $table) {
            $table->id();

            // Institution identification
            $table->string('code', 30)->unique();
            $table->string('name', 200);
            $table->string('slug', 150)->unique();

            // Institution classification
            $table->string('institution_type', 30);

            // Location
            $table->string('city', 100)->nullable();
            $table->string('state', 100)->nullable();
            $table->string('country', 100)->default('India');

            // Institutional configuration
            $table->string('timezone', 50)
                ->default('Asia/Kolkata');

            $table->json('settings')->nullable();

            // Status
            $table->boolean('is_active')->default(true);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenants');
    }
};
