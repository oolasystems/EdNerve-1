<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('audit_logs', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('tenant_id')->nullable()
                ->constrained('tenants')->nullOnDelete();
            $table->foreignId('actor_user_id')->nullable()
                ->constrained('users')->nullOnDelete();
            $table->foreignId('organization_unit_id')->nullable()
                ->constrained('organization_units')->nullOnDelete();
            $table->string('event', 120);
            $table->string('module', 80);
            $table->string('subject_type', 190)->nullable();
            $table->string('subject_id', 100)->nullable();
            $table->string('description', 500)->nullable();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 1000)->nullable();
            $table->string('request_id', 64)->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['tenant_id', 'created_at'], 'audit_tenant_created_idx');
            $table->index(['tenant_id', 'event'], 'audit_tenant_event_idx');
            $table->index(['tenant_id', 'actor_user_id'], 'audit_tenant_actor_idx');
            $table->index(['tenant_id', 'organization_unit_id', 'created_at'], 'audit_tenant_org_created_idx');
            $table->index(['subject_type', 'subject_id'], 'audit_subject_idx');
            $table->index('request_id', 'audit_request_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
    }
};
