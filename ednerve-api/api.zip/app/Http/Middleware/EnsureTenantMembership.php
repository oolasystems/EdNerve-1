<?php

namespace App\Http\Middleware;

use App\Services\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureTenantMembership
{
    public function __construct(private readonly TenantContext $tenantContext)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $tenant = $this->tenantContext->resolveForRequest($request);

        if (!$tenant) {
            return response()->json([
                'message' => 'Select an institution before accessing this resource.',
                'code' => 'TENANT_CONTEXT_REQUIRED',
            ], 422);
        }

        // Downstream controllers/services should use this resolved object/ID.
        $request->attributes->set('tenant', $tenant);
        $request->attributes->set('tenant_id', $tenant->id);


        return $next($request);
    }
}
