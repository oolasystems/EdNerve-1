<?php

namespace App\Http\Middleware;

use App\Services\RolePermissionResolver;
use App\Services\AuditService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequirePermission
{
    public function __construct(
        private readonly RolePermissionResolver $resolver,
        private readonly AuditService $audit,
    ) {}

    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();

        if (!$user) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        $tenantValue = $request->attributes->get('tenant_id');
        $organizationUnitValue = $request->attributes->get('organization_unit_id');

        $tenantId = is_numeric($tenantValue) ? (int) $tenantValue : null;
        $organizationUnitId = is_numeric($organizationUnitValue)
            ? (int) $organizationUnitValue
            : null;

        if (!$this->resolver->hasPermission(
            $user,
            $permission,
            $tenantId,
            $organizationUnitId
        )) {
            $this->audit->record(
                $request,
                'authorization.permission_denied',
                'authorization',
                $user,
                null,
                ['required_permission' => $permission],
                'A permission check was denied.'
            );

            return response()->json([
                'message' => 'You are not authorized to perform this action.',
                'code' => 'PERMISSION_DENIED',
                'required_permission' => $permission,
            ], 403);
        }

        return $next($request);
    }
}
