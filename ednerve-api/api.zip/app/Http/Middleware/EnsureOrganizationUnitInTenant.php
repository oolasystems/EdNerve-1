<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

/**
 * Validates an optional organization-unit selector against the already
 * validated tenant context. Must run after tenant.member.
 */
class EnsureOrganizationUnitInTenant
{
    public function handle(Request $request, Closure $next): Response
    {
        $tenantId = $request->attributes->get('tenant_id');

        if (!$tenantId) {
            return response()->json([
                'message' => 'Institution context is required before selecting an organization unit.',
                'code' => 'TENANT_CONTEXT_REQUIRED',
            ], 422);
        }

        // Accept either a route-bound model or a numeric route/input identifier.
        $routeValue = $request->route('organizationUnit');
        if (is_object($routeValue) && method_exists($routeValue, 'getKey')) {
            $routeValue = $routeValue->getKey();
        }

        $value = $routeValue ?? $request->input('organization_unit_id');

        if ($value === null || $value === '') {
            return response()->json([
                'message' => 'An organization_unit_id is required for this organization-scoped operation.',
                'code' => 'ORGANIZATION_UNIT_REQUIRED',
            ], 422);
        }

        if (!is_numeric($value) || (int) $value < 1) {
            return response()->json([
                'message' => 'The organization unit identifier is invalid.',
                'code' => 'INVALID_ORGANIZATION_UNIT',
            ], 422);
        }

        $organizationUnitId = (int) $value;
        $belongsToTenant = DB::table('organization_units')
            ->where('id', $organizationUnitId)
            ->where('tenant_id', (int) $tenantId)
            ->where('is_active', true)
            ->exists();

        if (!$belongsToTenant) {
            return response()->json([
                'message' => 'The selected organization unit does not belong to the active institution.',
                'code' => 'ORGANIZATION_UNIT_OUT_OF_SCOPE',
            ], 403);
        }

        $request->attributes->set('organization_unit_id', $organizationUnitId);

        return $next($request);
    }
}
