<?php

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
            'device_name' => ['nullable', 'string', 'max:100'],
        ]);

        $user = User::where('email', $credentials['email'])->first();

        if (
            !$user ||
            !Hash::check($credentials['password'], $user->password) ||
            $user->status !== 'active'
        ) {
            app(AuditService::class)->record(
                $request,
                'auth.login_failed',
                'authentication',
                $user,
                null,
                ['account_status' => $user?->status],
                'A login attempt failed.'
            );

            throw ValidationException::withMessages([
                'email' => ['The supplied credentials are invalid or the account is inactive.'],
            ]);
        }

        // First-party React SPA: use the secure Laravel session cookie.
        if ($this->isFirstPartySpaRequest($request)) {
            Auth::guard('web')->login($user);
            $request->session()->regenerate();

            $user->forceFill(['last_login_at' => now()])->save();

            app(AuditService::class)->record(
                $request,
                'auth.login_succeeded',
                'authentication',
                $user,
                null,
                ['auth_type' => 'session'],
                'User authenticated using the first-party session.'
            );

            return response()->json([
                'message' => 'Login successful.',
                'auth_type' => 'session',
                'user' => $this->userPayload($user),
            ]);
        }

        // Native/mobile and external API clients: issue a revocable Sanctum token.
        $tokenDays = max(1, (int) config('sanctum.token_expiration_days', 30));
        $token = $user->createToken(
            $credentials['device_name'] ?? 'mobile-device',
            ['*'],
            now()->addDays($tokenDays)
        );

        $user->forceFill(['last_login_at' => now()])->save();

        app(AuditService::class)->record(
            $request,
            'auth.login_succeeded',
            'authentication',
            $user,
            null,
            ['auth_type' => 'token', 'device_name' => $credentials['device_name'] ?? 'mobile-device'],
            'User authenticated using an API token.'
        );

        return response()->json([
            'message' => 'Login successful.',
            'auth_type' => 'token',
            'token_type' => 'Bearer',
            'access_token' => $token->plainTextToken,
            'expires_at' => now()->addDays($tokenDays)->toISOString(),
            'user' => $this->userPayload($user),
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $currentUser = $request->user();
        app(AuditService::class)->record(
            $request,
            'auth.logout',
            'authentication',
            $currentUser,
            null,
            null,
            'User logged out.'
        );

        $currentToken = $currentUser?->currentAccessToken();

        if ($currentToken instanceof PersonalAccessToken) {
            $currentToken->delete();
        } elseif (Auth::guard('web')->check()) {
            Auth::guard('web')->logout();

            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return response()->json(['message' => 'Logged out successfully.']);
    }

    public function me(Request $request): JsonResponse
    {
        $user = $request->user()->load([
            'tenants' => fn ($query) => $query
                ->where('tenants.is_active', true)
                ->wherePivot('membership_status', 'active')
                ->select('tenants.id', 'tenants.code', 'tenants.name', 'tenants.slug'),
        ]);

        return response()->json([
            'user' => $this->userPayload($user),
            'memberships' => $user->tenants->map(fn ($tenant) => [
                'id' => $tenant->id,
                'code' => $tenant->code,
                'name' => $tenant->name,
                'slug' => $tenant->slug,
            ])->values(),
        ]);
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required', 'email']]);

        Password::sendResetLink(['email' => $request->string('email')->toString()]);

        // Same response regardless of whether the address exists.
        return response()->json([
            'message' => 'If the account exists, a password reset link will be sent.',
        ]);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'token' => ['required', 'string'],
            'email' => ['required', 'email'],
            'password' => ['required', 'string', 'min:12', 'confirmed'],
        ]);

        $status = Password::reset(
            $validated,
            function (User $user, string $password) use ($request): void {
                $user->forceFill([
                    'password' => Hash::make($password),
                    'remember_token' => Str::random(60),
                ])->save();

                // Revoke all existing mobile/API tokens after a password reset.
                $user->tokens()->delete();

                app(AuditService::class)->record(
                    $request,
                    'auth.password_reset',
                    'authentication',
                    $user,
                    null,
                    null,
                    'Password reset completed; existing API tokens were revoked.'
                );
            }
        );

        if ($status !== Password::PASSWORD_RESET) {
            return response()->json([
                'message' => 'The password reset link is invalid or has expired.',
            ], 422);
        }

        return response()->json(['message' => 'Password has been reset successfully.']);
    }

    private function isFirstPartySpaRequest(Request $request): bool
    {
        return \Laravel\Sanctum\Http\Middleware\EnsureFrontendRequestsAreStateful::fromFrontend($request);
    }

    private function userPayload(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'status' => $user->status,
            'email_verified_at' => $user->email_verified_at,
            'last_login_at' => $user->last_login_at,
        ];
    }
}
