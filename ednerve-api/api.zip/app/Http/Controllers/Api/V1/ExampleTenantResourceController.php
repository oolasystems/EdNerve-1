<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Demonstration controller for Phase 2.5 tenant and organization scoping.
 *
 * Assumes an example_resources table with:
 * id, tenant_id, organization_unit_id (nullable), name, description (nullable),
 * created_at and updated_at.
 * This is a reference implementation, not a production ERP module.
 */
class ExampleTenantResourceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tenantId = (int) $request->attributes->get('tenant_id');

        abort_unless($tenantId > 0, 422, 'Institution context is required.');

        $query = DB::table('example_resources')
            ->where('tenant_id', $tenantId);

        // If organization scope was validated by tenant.organization,
        // constrain results to that organization unit.
        $organizationUnitId = $request->attributes->get('organization_unit_id');
        if ($organizationUnitId !== null) {
            $query->where('organization_unit_id', (int) $organizationUnitId);
        }

        return response()->json([
            'data' => $query->orderBy('id')->get(),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenantId = (int) $request->attributes->get('tenant_id');
        abort_unless($tenantId > 0, 422, 'Institution context is required.');

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:150'],
            'description' => ['nullable', 'string', 'max:2000'],
        ]);

        // Never accept tenant_id or organization_unit_id from the payload.
        // Both values must come from validated middleware context.
        $organizationUnitId = $request->attributes->get('organization_unit_id');

        $id = DB::table('example_resources')->insertGetId([
            'tenant_id' => $tenantId,
            'organization_unit_id' => $organizationUnitId,
            'name' => $validated['name'],
            'description' => $validated['description'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $resource = DB::table('example_resources')
            ->where('tenant_id', $tenantId)
            ->where('id', $id)
            ->first();

        return response()->json(['data' => $resource], 201);
    }
}
