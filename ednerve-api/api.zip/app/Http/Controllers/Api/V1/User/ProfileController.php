<?php

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Services\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

class ProfileController extends Controller
{
    /**
     * Return the authenticated user's own profile.
     */
    public function show(Request $request): JsonResponse
    {
        return response()->json([
            'user' => $this->profilePayload($request),
        ]);
    }

    /**
     * Update only self-service profile fields.
     * Email and account status are intentionally not editable here.
     */
    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['sometimes', 'required', 'string', 'max:150'],
            'phone' => ['sometimes', 'nullable', 'string', 'max:30'],
        ]);

        if ($validated === []) {
            throw ValidationException::withMessages([
                'profile' => ['Provide at least one profile field to update.'],
            ]);
        }

        $user = $request->user();
        $oldValues = $user->only(array_keys($validated));
        $user->forceFill($validated)->save();

        app(AuditService::class)->record(
            $request,
            'profile.updated',
            'identity',
            $user,
            $oldValues,
            $user->only(array_keys($validated)),
            'User updated their own profile.'
        );

        return response()->json([
            'message' => 'Profile updated successfully.',
            'user' => $this->profilePayload($request),
        ]);
    }

    /**
     * Change the authenticated user's password.
     * For token-authenticated clients, preserve the current token and revoke
     * all other personal access tokens. For SPA sessions, revoke all API tokens.
     */
    public function changePassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'current_password' => ['required', 'string', 'current_password'],
            'password' => [
                'required',
                'string',
                'confirmed',
                Password::min(12)->letters()->mixedCase()->numbers()->symbols(),
            ],
        ]);

        $user = $request->user();

        $user->forceFill([
            'password' => Hash::make($validated['password']),
        ])->save();

        app(AuditService::class)->record(
            $request,
            'profile.password_changed',
            'identity',
            $user,
            null,
            null,
            'User changed their password; other API tokens were revoked.'
        );

        $currentToken = $user->currentAccessToken();

        if ($currentToken instanceof PersonalAccessToken) {
            $user->tokens()
                ->where('id', '!=', $currentToken->getKey())
                ->delete();
        } else {
            $user->tokens()->delete();
        }

        return response()->json([
            'message' => 'Password changed successfully. Other active API tokens have been revoked.',
        ]);
    }

    private function profilePayload(Request $request): array
    {
        $user = $request->user();

        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'status' => $user->status,
            'email_verified_at' => $user->email_verified_at,
            'last_login_at' => $user->last_login_at,
            'created_at' => $user->created_at,
        ];
    }
}
