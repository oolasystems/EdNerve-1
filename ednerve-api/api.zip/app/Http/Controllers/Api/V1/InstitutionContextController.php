<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\TenantContext;
use App\Services\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class InstitutionContextController extends Controller
{
    public function __construct(private readonly TenantContext $tenantContext)
    {
    }

    /**
     * Return institutions the authenticated user can access.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'institutions' => $this->tenantContext->accessibleTenants($user)
                ->map(fn ($tenant) => $this->tenantPayload($tenant))
                ->values(),
        ]);
    }

    /**
     * Validate and select an institution context.
     *
     * SPA clients retain the selected context in their authenticated session.
     * Mobile/token clients should send X-Tenant-ID on each tenant-scoped request.
     */
    public function switch(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'tenant_id' => ['required', 'integer', 'min:1'],
        ]);

        $previousTenantId = $request->hasSession()
            ? $request->session()->get(TenantContext::SESSION_KEY)
            : null;

        $tenant = $this->tenantContext->findAccessibleTenant(
            $request->user(),
            (int) $validated['tenant_id']
        );

        if ($request->hasSession()) {
            $request->session()->put(TenantContext::SESSION_KEY, $tenant->id);
        }

        app(AuditService::class)->record(
            $request,
            'institution.context_switched',
            'tenancy',
            $tenant,
            ['previous_tenant_id' => $previousTenantId],
            ['active_tenant_id' => $tenant->id],
            'User selected an institutional context.',
            (int) $tenant->id
        );

        return response()->json([
            'message' => 'Institution context selected successfully.',
            'active_institution' => $this->tenantPayload($tenant),
            'context_header' => 'X-Tenant-ID',
            'context_header_value' => (string) $tenant->id,
        ]);
    }

    /**
     * Return the currently resolved institution context.
     */
    public function current(Request $request): JsonResponse
    {
        $tenant = $this->tenantContext->resolveForRequest($request);

        return response()->json([
            'active_institution' => $tenant ? $this->tenantPayload($tenant) : null,
        ]);
    }

    private function tenantPayload($tenant): array
    {
        return [
            'id' => $tenant->id,
            'code' => $tenant->code,
            'name' => $tenant->name,
            'slug' => $tenant->slug,
            'institution_type' => $tenant->institution_type,
            'city' => $tenant->city,
            'state' => $tenant->state,
        ];
    }
}
