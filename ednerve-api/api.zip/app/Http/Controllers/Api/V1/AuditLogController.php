<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuditLogController extends Controller
{
    /**
     * Return audit history for the currently selected institution only.
     */
    public function index(Request $request): JsonResponse
    {
        $tenantId = $request->attributes->get('tenant_id');

        abort_unless(is_numeric($tenantId), 422, 'Institution context is required.');

        $filters = $request->validate([
            'event' => ['nullable', 'string', 'max:120'],
            'module' => ['nullable', 'string', 'max:80'],
            'actor_user_id' => ['nullable', 'integer', 'min:1'],
            'subject_type' => ['nullable', 'string', 'max:190'],
            'subject_id' => ['nullable', 'string', 'max:100'],
            'from' => ['nullable', 'date'],
            'to' => ['nullable', 'date', 'after_or_equal:from'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $query = AuditLog::query()
            ->where('tenant_id', (int) $tenantId)
            ->with(['actor:id,name,email'])
            ->orderByDesc('id');

        $organizationUnitId = $request->attributes->get('organization_unit_id');
        if (is_numeric($organizationUnitId)) {
            $query->where('organization_unit_id', (int) $organizationUnitId);
        }

        foreach (['event', 'module', 'actor_user_id', 'subject_type', 'subject_id'] as $field) {
            if (isset($filters[$field])) {
                $query->where($field, $filters[$field]);
            }
        }

        if (!empty($filters['from'])) {
            $query->whereDate('created_at', '>=', $filters['from']);
        }

        if (!empty($filters['to'])) {
            $query->whereDate('created_at', '<=', $filters['to']);
        }

        $logs = $query->paginate((int) ($filters['per_page'] ?? 25));

        return response()->json([
            'data' => $logs->items(),
            'meta' => [
                'current_page' => $logs->currentPage(),
                'last_page' => $logs->lastPage(),
                'per_page' => $logs->perPage(),
                'total' => $logs->total(),
            ],
        ]);
    }

    /**
     * Return one audit record, constrained to the active institution.
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $tenantId = $request->attributes->get('tenant_id');

        abort_unless(is_numeric($tenantId), 422, 'Institution context is required.');

        $log = AuditLog::query()
            ->where('tenant_id', (int) $tenantId)
            ->with(['actor:id,name,email'])
            ->findOrFail($id);

        return response()->json(['data' => $log]);
    }
}
