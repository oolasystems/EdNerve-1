<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\RolePermissionResolver;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuthorizationController extends Controller
{
    public function __construct(private readonly RolePermissionResolver $resolver) {}

    /** Effective roles and permissions for the current request context. */
    public function me(Request $request): JsonResponse
    {
        $tenantId = $request->attributes->get('tenant_id');
        $orgValue = $request->query('organization_unit_id');
        $organizationUnitId = is_numeric($orgValue) ? (int) $orgValue : null;

        if ($organizationUnitId !== null && $tenantId === null) {
            return response()->json([
                'message' => 'An institution context is required for organization-scoped authorization.',
                'code' => 'TENANT_CONTEXT_REQUIRED',
            ], 422);
        }

        return response()->json([
            'context' => [
                'tenant_id' => $tenantId ? (int) $tenantId : null,
                'organization_unit_id' => $organizationUnitId,
            ],
            'roles' => $this->resolver->roleCodes($request->user(), $tenantId ? (int) $tenantId : null, $organizationUnitId),
            'permissions' => $this->resolver->permissionCodes($request->user(), $tenantId ? (int) $tenantId : null, $organizationUnitId),
        ]);
    }

    /** Check one permission for the authenticated user's active context. */
    public function check(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'permission' => ['required', 'string', 'max:150'],
            'organization_unit_id' => ['nullable', 'integer', 'min:1'],
        ]);

        $tenantId = $request->attributes->get('tenant_id');
        $organizationUnitId = $validated['organization_unit_id'] ?? null;

        if ($organizationUnitId !== null && $tenantId === null) {
            return response()->json(['message' => 'Institution context is required.', 'code' => 'TENANT_CONTEXT_REQUIRED'], 422);
        }

        $allowed = $this->resolver->hasPermission(
            $request->user(),
            $validated['permission'],
            $tenantId ? (int) $tenantId : null,
            $organizationUnitId ? (int) $organizationUnitId : null,
        );

        return response()->json([
            'permission' => $validated['permission'],
            'allowed' => $allowed,
        ]);
    }
}
