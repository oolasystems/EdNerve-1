<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Role extends Model {
 protected $fillable=['tenant_id','code','name','description','scope_type','is_system','is_active'];
 protected function casts(): array { return ['is_system'=>'boolean','is_active'=>'boolean']; }
 public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
 public function permissions(): BelongsToMany { return $this->belongsToMany(Permission::class,'role_permission')->withTimestamps(); }
 public function assignments(): HasMany { return $this->hasMany(UserRoleAssignment::class); }
}
