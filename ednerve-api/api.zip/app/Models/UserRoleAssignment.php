<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class UserRoleAssignment extends Model {
 protected $fillable=['user_id','role_id','tenant_id','organization_unit_id','assigned_by','starts_at','ends_at','is_active'];
 protected function casts(): array { return ['starts_at'=>'datetime','ends_at'=>'datetime','is_active'=>'boolean']; }
 public function user(): BelongsTo { return $this->belongsTo(User::class); }
 public function role(): BelongsTo { return $this->belongsTo(Role::class); }
 public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
 public function organizationUnit(): BelongsTo { return $this->belongsTo(OrganizationUnit::class); }
 public function assigner(): BelongsTo { return $this->belongsTo(User::class,'assigned_by'); }
}
