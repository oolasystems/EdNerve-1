<?php

use App\Http\Controllers\Api\V1\Auth\AuthController;
use App\Http\Controllers\Api\V1\AuthorizationController;
use App\Http\Controllers\Api\V1\AuditLogController;
use App\Http\Controllers\Api\V1\InstitutionContextController;
use App\Http\Controllers\Api\V1\ExampleTenantResourceController;
use App\Http\Controllers\Api\V1\User\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API V1 Routes
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function (): void {

    /*
    |--------------------------------------------------------------------------
    | Health Check
    |--------------------------------------------------------------------------
    */

    Route::get('/health', function () {
        return response()->json([
            'status' => 'ok',
            'message' => 'OolaEdNerve API is running',
        ]);
    });

    /*
    |--------------------------------------------------------------------------
    | Public Authentication Routes
    |--------------------------------------------------------------------------
    */

    Route::prefix('auth')->group(function (): void {

        Route::post('/login', [AuthController::class, 'login'])
            ->middleware('throttle:6,1');

        Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])
            ->middleware('throttle:3,1');

        Route::post('/reset-password', [AuthController::class, 'resetPassword'])
            ->middleware('throttle:6,1');

        /*
        |--------------------------------------------------------------------------
        | Authenticated Authentication Routes
        |--------------------------------------------------------------------------
        */

        Route::middleware('auth:sanctum')->group(function (): void {

            Route::post('/logout', [AuthController::class, 'logout']);

            Route::get('/me', [AuthController::class, 'me']);

        });
    });

    /*
    |--------------------------------------------------------------------------
    | Authenticated User Profile Routes
    |--------------------------------------------------------------------------
    */

    Route::middleware('auth:sanctum')
        ->prefix('profile')
        ->group(function (): void {

            Route::get('/', [ProfileController::class, 'show']);

            Route::patch('/', [ProfileController::class, 'update']);

            Route::put('/password', [ProfileController::class, 'changePassword'])
                ->middleware('throttle:5,1');

        });

    /*
    |--------------------------------------------------------------------------
    | Institutional Context and Membership Switching
    |--------------------------------------------------------------------------
    | These routes require authentication but do not require an already
    | selected tenant. Users must be able to list and switch institutions.
    |--------------------------------------------------------------------------
    */

    Route::middleware('auth:sanctum')
        ->prefix('institution-context')
        ->group(function (): void {

            Route::get('/institutions', [
                InstitutionContextController::class,
                'index',
            ]);

            Route::post('/switch', [
                InstitutionContextController::class,
                'switch',
            ])->middleware('throttle:20,1');

            Route::get('/current', [
                InstitutionContextController::class,
                'current',
            ]);

        });

    /*
    |--------------------------------------------------------------------------
    | Authorization and Permission Routes
    |--------------------------------------------------------------------------
    */

    Route::middleware('auth:sanctum')->group(function (): void {

        Route::get('/authorization/me', [
            AuthorizationController::class,
            'me',
        ]);

        Route::post('/authorization/check', [
            AuthorizationController::class,
            'check',
        ])->middleware('throttle:30,1');

    });


    /*
    |--------------------------------------------------------------------------
    | Audit Logs – Phase 2.6
    |--------------------------------------------------------------------------
    */
    Route::middleware(['auth:sanctum', 'tenant.member'])->group(function (): void {
        Route::get('/audit-logs', [AuditLogController::class, 'index'])
            ->middleware('permission:audit_logs.view');

        Route::get('/audit-logs/{id}', [AuditLogController::class, 'show'])
            ->whereNumber('id')
            ->middleware('permission:audit_logs.view');

        Route::get('/audit-logs/organization/{organizationUnit}', [AuditLogController::class, 'index'])
            ->middleware([
                'tenant.organization',
                'permission:audit_logs.view',
            ]);
    });

    /*
    |--------------------------------------------------------------------------
    | Tenant-Aware Protected Resources – Phase 2.5
    |--------------------------------------------------------------------------
    */

    Route::middleware([
        'auth:sanctum',
        'tenant.member',
    ])->group(function (): void {

        /*
        |--------------------------------------------------------------------------
        | Institution-Wide Resource Access
        |--------------------------------------------------------------------------
        */

        Route::get(
            '/example-resources',
            [ExampleTenantResourceController::class, 'index']
        )->middleware('permission:example_resources.view');

        /*
        |--------------------------------------------------------------------------
        | Organization-Scoped Resource Access
        |--------------------------------------------------------------------------
        */

        Route::post(
            '/example-resources',
            [ExampleTenantResourceController::class, 'store']
        )->middleware([
            'tenant.organization',
            'permission:example_resources.create',
        ]);

    });

});
